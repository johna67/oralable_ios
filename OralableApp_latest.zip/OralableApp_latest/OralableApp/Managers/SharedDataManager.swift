import Foundation
import CloudKit

// MARK: - Shared Data Models

struct SharedPatientData: Identifiable {
    let id: UUID
    let patientID: String          // Anonymized patient identifier
    let dentistID: String          // Dentist's Apple ID
    let shareCode: String          // 6-digit share code
    let accessGrantedDate: Date
    let expiryDate: Date?          // Optional time limit
    let permissions: SharePermission
    let isActive: Bool

    init(patientID: String, dentistID: String, shareCode: String, permissions: SharePermission = .readOnly, expiryDate: Date? = nil) {
        self.id = UUID()
        self.patientID = patientID
        self.dentistID = dentistID
        self.shareCode = shareCode
        self.accessGrantedDate = Date()
        self.expiryDate = expiryDate
        self.permissions = permissions
        self.isActive = true
    }
}

enum SharePermission: String, Codable {
    case readOnly = "read_only"
    case readWrite = "read_write"  // Future use
}

struct SharedDentist: Identifiable {
    let id: String
    let dentistID: String
    let dentistName: String?
    let sharedDate: Date
    let expiryDate: Date?
    let isActive: Bool
}

// MARK: - Shared Data Manager

@MainActor
class SharedDataManager: ObservableObject {
    @Published var sharedDentists: [SharedDentist] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let container: CKContainer
    private let publicDatabase: CKDatabase
    private let authenticationManager: AuthenticationManager
    private let healthKitManager: HealthKitManager
    private weak var sensorDataProcessor: SensorDataProcessor?

    init(authenticationManager: AuthenticationManager, healthKitManager: HealthKitManager, sensorDataProcessor: SensorDataProcessor? = nil) {
        // Use shared container for both patient and dentist apps
        self.container = CKContainer(identifier: "iCloud.com.jacdental.oralable.shared")

        // Use public database for data sharing between patient and dentist apps
        // The public database allows patients to share their data with dentists via share codes
        // For development, use private database which auto-creates schemas
        // For production, use public database (schema must be deployed in CloudKit Dashboard)
        #if DEBUG
        self.publicDatabase = container.privateCloudDatabase
        #else
        self.publicDatabase = container.publicCloudDatabase
        #endif

        // Store reference to authentication manager
        self.authenticationManager = authenticationManager

        // Store reference to HealthKit manager
        self.healthKitManager = healthKitManager

        // Store reference to sensor data processor for sensor data access
        self.sensorDataProcessor = sensorDataProcessor

        loadSharedDentists()
    }

    // Computed property for backward compatibility
    private var userID: String? {
        return authenticationManager.userID
    }

    // MARK: - Patient Side: Generate Share Code

    func generateShareCode() -> String {
        // Generate 6-digit code
        let code = String(format: "%06d", Int.random(in: 0...999999))
        return code
    }

    func createShareInvitation() async throws -> String {
        guard let patientID = userID else {
            throw ShareError.notAuthenticated
        }

        isLoading = true
        errorMessage = nil

        let shareCode = generateShareCode()

        // Create CloudKit record
        let recordID = CKRecord.ID(recordName: UUID().uuidString)
        let record = CKRecord(recordType: "ShareInvitation", recordID: recordID)

        record["patientID"] = patientID as CKRecordValue
        record["shareCode"] = shareCode as CKRecordValue
        record["createdDate"] = Date() as CKRecordValue
        record["expiryDate"] = Calendar.current.date(byAdding: .hour, value: 48, to: Date()) as CKRecordValue?
        record["isActive"] = 1 as CKRecordValue
        record["dentistID"] = "" as CKRecordValue  // Will be filled when dentist enters code

        do {
            try await publicDatabase.save(record)
            isLoading = false
            return shareCode
        } catch {
            isLoading = false
            errorMessage = "Failed to create share invitation: \(error.localizedDescription)"
            throw ShareError.cloudKitError(error)
        }
    }

    func revokeAccessForDentist(dentistID: String) async throws {
        guard let patientID = userID else {
            throw ShareError.notAuthenticated
        }

        isLoading = true
        errorMessage = nil

        // Query for the share record
        let predicate = NSPredicate(format: "patientID == %@ AND dentistID == %@", patientID, dentistID)
        let query = CKQuery(recordType: "SharedPatientData", predicate: predicate)

        do {
            let (matchResults, _) = try await publicDatabase.records(matching: query)

            for (_, result) in matchResults {
                switch result {
                case .success(let record):
                    // Mark as inactive
                    record["isActive"] = 0 as CKRecordValue
                    try await publicDatabase.save(record)
                case .failure(let error):
                    Logger.shared.error("[SharedDataManager] Error fetching record: \(error)")
                }
            }

            // Reload shared dentists
            await loadSharedDentists()

            isLoading = false
        } catch {
            isLoading = false
            errorMessage = "Failed to revoke access: \(error.localizedDescription)"
            throw ShareError.cloudKitError(error)
        }
    }

    func loadSharedDentists() {
        guard let patientID = userID else { return }

        Task {
            isLoading = true

            let predicate = NSPredicate(format: "patientID == %@ AND isActive == 1", patientID)
            let query = CKQuery(recordType: "SharedPatientData", predicate: predicate)

            do {
                let (matchResults, _) = try await publicDatabase.records(matching: query)

                var dentists: [SharedDentist] = []
                for (_, result) in matchResults {
                    switch result {
                    case .success(let record):
                        if let dentistID = record["dentistID"] as? String,
                           let sharedDate = record["accessGrantedDate"] as? Date {
                            let dentist = SharedDentist(
                                id: record.recordID.recordName,
                                dentistID: dentistID,
                                dentistName: record["dentistName"] as? String,
                                sharedDate: sharedDate,
                                expiryDate: record["expiryDate"] as? Date,
                                isActive: (record["isActive"] as? Int) == 1
                            )
                            dentists.append(dentist)
                        }
                    case .failure(let error):
                        Logger.shared.error("[SharedDataManager] Error loading dentist: \(error)")
                    }
                }

                await MainActor.run {
                    self.sharedDentists = dentists
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "Failed to load shared dentists: \(error.localizedDescription)"
                    self.isLoading = false
                }
            }
        }
    }

    // MARK: - Get Patient Health Data for Sharing

    func getPatientHealthDataForSharing(from startDate: Date, to endDate: Date) async throws -> [HealthDataRecord] {
        // Fetch HealthKit data if authorized
        var healthKitData: HealthKitDataForSharing? = nil

        if healthKitManager.isAuthorized {
            do {
                // Fetch heart rate data
                let heartRateReadings = try await healthKitManager.readHeartRateSamples(
                    from: startDate,
                    to: endDate
                )

                // Fetch SpO2 data
                let spo2Readings = try await healthKitManager.readBloodOxygenSamples(
                    from: startDate,
                    to: endDate
                )

                // Create HealthKit data structure
                healthKitData = HealthKitDataForSharing(
                    heartRateReadings: heartRateReadings,
                    spo2Readings: spo2Readings,
                    sleepData: nil  // TODO: Add sleep data fetching
                )

                Logger.shared.info("[SharedDataManager] Fetched HealthKit data: \(heartRateReadings.count) HR, \(spo2Readings.count) SpO2")
            } catch {
                Logger.shared.warning("[SharedDataManager] Failed to fetch HealthKit data: \(error)")
                // Continue without HealthKit data
            }
        }

        // Get sensor data from processor
        var sensorRecords: [HealthDataRecord] = []

        if let processor = sensorDataProcessor {
            let sensorData = processor.sensorDataHistory.filter {
                $0.timestamp >= startDate && $0.timestamp <= endDate
            }

            if !sensorData.isEmpty {
                // Convert to shareable format
                let bruxismData = BruxismSessionData(sensorData: sensorData)

                if let encodedData = try? JSONEncoder().encode(bruxismData) {
                    let record = HealthDataRecord(
                        recordID: UUID().uuidString,
                        recordingDate: startDate,
                        dataType: "bruxism_session",
                        measurements: encodedData,
                        sessionDuration: endDate.timeIntervalSince(startDate),
                        healthKitData: healthKitData
                    )
                    sensorRecords.append(record)
                }
            }
        }

        return sensorRecords
    }

    // MARK: - Upload Recording Session to CloudKit

    func uploadRecordingSession(_ session: RecordingSession) async throws {
        guard let patientID = userID else {
            throw ShareError.notAuthenticated
        }

        guard session.status == .completed, let endTime = session.endTime else {
            Logger.shared.warning("[SharedDataManager] Cannot upload incomplete session")
            return
        }

        Logger.shared.info("[SharedDataManager] Uploading session \(session.id) to CloudKit")

        // Get sensor data for the session time range
        var bruxismEvents = 0
        var averageIntensity = 0.0
        var peakIntensity = 0.0
        var heartRateData: [Double] = []
        var oxygenSaturation: [Double] = []

        if let processor = sensorDataProcessor {
            // Filter sensor data to this session's time range
            let sessionData = processor.sensorDataHistory.filter {
                $0.timestamp >= session.startTime && $0.timestamp <= endTime
            }

            Logger.shared.info("[SharedDataManager] Found \(sessionData.count) sensor readings for session")

            // Calculate bruxism events (simple threshold-based detection)
            // A bruxism event is detected when accelerometer magnitude exceeds threshold
            let bruxismThreshold = 2.0 // g-force threshold
            var isInEvent = false

            for data in sessionData {
                let magnitude = data.accelerometer.magnitude

                if magnitude > bruxismThreshold {
                    if !isInEvent {
                        bruxismEvents += 1
                        isInEvent = true
                    }
                    // Track intensity during events
                    if magnitude > peakIntensity {
                        peakIntensity = magnitude
                    }
                } else {
                    isInEvent = false
                }
            }

            // Calculate average intensity from all readings
            if !sessionData.isEmpty {
                let totalIntensity = sessionData.reduce(0.0) { $0 + $1.accelerometer.magnitude }
                averageIntensity = totalIntensity / Double(sessionData.count)
            }

            // Extract heart rate data
            heartRateData = sessionData.compactMap { $0.heartRate?.bpm }

            // Extract SpO2 data
            oxygenSaturation = sessionData.compactMap { $0.spo2?.percentage }

            Logger.shared.info("[SharedDataManager] Calculated metrics: \(bruxismEvents) events, peak: \(peakIntensity), avg: \(averageIntensity)")
        }

        // Create CloudKit record
        let recordID = CKRecord.ID(recordName: UUID().uuidString)
        let record = CKRecord(recordType: "HealthDataRecord", recordID: recordID)

        record["patientID"] = patientID as CKRecordValue
        record["recordingDate"] = session.startTime as CKRecordValue
        record["sessionDuration"] = session.duration as CKRecordValue
        record["bruxismEvents"] = bruxismEvents as CKRecordValue
        record["averageIntensity"] = averageIntensity as CKRecordValue
        record["peakIntensity"] = peakIntensity as CKRecordValue

        // Store heart rate and SpO2 arrays as JSON data
        if !heartRateData.isEmpty {
            if let hrData = try? JSONEncoder().encode(heartRateData) {
                record["heartRateData"] = hrData as CKRecordValue
            }
        }

        if !oxygenSaturation.isEmpty {
            if let spo2Data = try? JSONEncoder().encode(oxygenSaturation) {
                record["oxygenSaturation"] = spo2Data as CKRecordValue
            }
        }

        do {
            try await publicDatabase.save(record)
            Logger.shared.info("[SharedDataManager] ✅ Successfully uploaded session \(session.id) to CloudKit")
        } catch {
            Logger.shared.error("[SharedDataManager] ❌ Failed to upload session: \(error)")
            throw ShareError.cloudKitError(error)
        }
    }
}

// MARK: - Share Errors

enum ShareError: LocalizedError {
    case notAuthenticated
    case cloudKitError(Error)
    case invalidShareCode
    case shareCodeExpired
    case dentistNotFound

    var errorDescription: String? {
        switch self {
        case .notAuthenticated:
            return "You must be signed in to share data"
        case .cloudKitError(let error):
            return "Cloud error: \(error.localizedDescription)"
        case .invalidShareCode:
            return "Invalid share code"
        case .shareCodeExpired:
            return "Share code has expired"
        case .dentistNotFound:
            return "Dentist not found"
        }
    }
}

// MARK: - Health Data Record (for sharing)

struct HealthDataRecord: Codable {
    let recordID: String
    let recordingDate: Date
    let dataType: String
    let measurements: Data
    let sessionDuration: TimeInterval
    let healthKitData: HealthKitDataForSharing?  // NEW: Include HealthKit data
}

// MARK: - HealthKit Data for Sharing

struct HealthKitDataForSharing: Codable {
    let heartRateReadings: [HealthDataReading]
    let spo2Readings: [HealthDataReading]
    let sleepData: [SleepDataPoint]?

    var averageHeartRate: Double? {
        guard !heartRateReadings.isEmpty else { return nil }
        return heartRateReadings.reduce(0.0) { $0 + $1.value } / Double(heartRateReadings.count)
    }

    var averageSpO2: Double? {
        guard !spo2Readings.isEmpty else { return nil }
        return spo2Readings.reduce(0.0) { $0 + $1.value } / Double(spo2Readings.count)
    }
}

struct SleepDataPoint: Codable {
    let startDate: Date
    let endDate: Date
    let sleepStage: String  // "deep", "light", "rem", "awake"
}

// MARK: - Bruxism Session Data (for sharing sensor data)

/// Serializable structure containing bruxism sensor data for sharing with dentists
struct BruxismSessionData: Codable {
    let sensorReadings: [SerializableSensorData]
    let recordingCount: Int
    let startDate: Date
    let endDate: Date

    init(sensorData: [SensorData]) {
        self.sensorReadings = sensorData.map { SerializableSensorData(from: $0) }
        self.recordingCount = sensorData.count
        self.startDate = sensorData.first?.timestamp ?? Date()
        self.endDate = sensorData.last?.timestamp ?? Date()
    }
}

/// Simplified sensor data structure for serialization
struct SerializableSensorData: Codable {
    let timestamp: Date

    // PPG data
    let ppgRed: Int32
    let ppgIR: Int32
    let ppgGreen: Int32

    // Accelerometer data
    let accelX: Int16
    let accelY: Int16
    let accelZ: Int16
    let accelMagnitude: Double

    // Temperature
    let temperatureCelsius: Double

    // Battery
    let batteryPercentage: Int

    // Calculated metrics
    let heartRateBPM: Double?
    let heartRateQuality: Double?
    let spo2Percentage: Double?
    let spo2Quality: Double?

    init(from sensorData: SensorData) {
        self.timestamp = sensorData.timestamp

        // PPG data
        self.ppgRed = sensorData.ppg.red
        self.ppgIR = sensorData.ppg.ir
        self.ppgGreen = sensorData.ppg.green

        // Accelerometer data
        self.accelX = sensorData.accelerometer.x
        self.accelY = sensorData.accelerometer.y
        self.accelZ = sensorData.accelerometer.z
        self.accelMagnitude = sensorData.accelerometer.magnitude

        // Temperature
        self.temperatureCelsius = sensorData.temperature.celsius

        // Battery
        self.batteryPercentage = sensorData.battery.percentage

        // Calculated metrics
        self.heartRateBPM = sensorData.heartRate?.bpm
        self.heartRateQuality = sensorData.heartRate?.quality
        self.spo2Percentage = sensorData.spo2?.percentage
        self.spo2Quality = sensorData.spo2?.quality
    }
}
