import Foundation

struct BatteryStatus: Codable {
    let percentage: Int
    let timestamp: Date
}
