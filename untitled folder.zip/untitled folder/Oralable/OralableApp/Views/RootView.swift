import SwiftUI

public struct RootView: View {
    public var body: some View {
        DashboardView()
    }
}
