//
//  SettingsView.swift
//  OralableApp
//
//  Created: November 11, 2025
//  Uses SettingsViewModel (MVVM pattern)
//

import SwiftUI

struct SettingsView: View {
    @StateObject private var viewModel: SettingsViewModel
    @EnvironmentObject var dependencies: AppDependencies
    @EnvironmentObject var designSystem: DesignSystem
    @EnvironmentObject var authenticationManager: AuthenticationManager
    @EnvironmentObject var subscriptionManager: SubscriptionManager
    @EnvironmentObject var appStateManager: AppStateManager
    @EnvironmentObject var healthKitManager: HealthKitManager
    @State private var showingExportSheet = false
    @State private var showingAuthenticationView = false
    @State private var showingSubscriptionView = false
    @State private var showingSignOutAlert = false
    @State private var showingChangeModeAlert = false

    // Viewer Mode flag - when true, certain settings are read-only
    let isViewerMode: Bool

    init(viewModel: SettingsViewModel, isViewerMode: Bool = false) {
        self.isViewerMode = isViewerMode
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    var body: some View {
        NavigationView {
            List {
                // Viewer Mode Info (only shown in viewer mode)
                if isViewerMode {
                    Section {
                        HStack(spacing: designSystem.spacing.md) {
                            Image(systemName: "eye.fill")
                                .foregroundColor(.blue)
                                .font(.title2)

                            VStack(alignment: .leading, spacing: 4) {
                                Text("Viewer Mode")
                                    .font(designSystem.typography.body)
                                    .foregroundColor(designSystem.colors.textPrimary)

                                Text("Settings are read-only in viewer mode")
                                    .font(designSystem.typography.caption)
                                    .foregroundColor(designSystem.colors.textSecondary)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }

                accountAndPreferencesGroup(viewModel)
                deviceAndNotificationsGroup(viewModel)
                healthIntegrationGroup(viewModel)
                dataAndPrivacyGroup(viewModel)
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.large)
        }
        .alert("Clear All Data?", isPresented: Binding(
            get: { viewModel.showClearDataConfirmation },
            set: { viewModel.showClearDataConfirmation = $0 }
        )) {
            Button("Cancel", role: .cancel) {}
            Button("Clear", role: .destructive) {
                viewModel.clearAllData()
            }
        } message: {
            Text("This will permanently delete all historical data. This action cannot be undone.")
        }
        .alert("Reset Settings?", isPresented: Binding(
            get: { viewModel.showResetConfirmation },
            set: { viewModel.showResetConfirmation = $0 }
        )) {
            Button("Cancel", role: .cancel) {}
            Button("Reset", role: .destructive) {
                viewModel.resetToDefaults()
            }
        } message: {
            Text("This will reset all settings to their default values.")
        }
        .sheet(isPresented: $showingExportSheet) {
            ShareView(sensorDataProcessor: dependencies.sensorDataProcessor, deviceManager: dependencies.deviceManager)
        }
        .sheet(isPresented: $showingAuthenticationView) {
            NavigationView {
                AuthenticationView(sharedAuthManager: authenticationManager)
            }
        }
        .sheet(isPresented: $showingSubscriptionView) {
            SubscriptionTierSelectionView()
        }
        .alert("Sign Out?", isPresented: $showingSignOutAlert) {
            Button("Cancel", role: .cancel) {}
            Button("Sign Out", role: .destructive) {
                authenticationManager.signOut()
            }
        } message: {
            Text("Are you sure you want to sign out? You'll need to sign in again to access subscription features.")
        }
        .alert("Change Mode?", isPresented: $showingChangeModeAlert) {
            Button("Cancel", role: .cancel) {}
            Button("Change Mode", role: .destructive) {
                appStateManager.clearMode()
            }
        } message: {
            Text("Changing modes will restart the app and may require signing in again. Are you sure?")
        }
    }

    // MARK: - View Groups

    @ViewBuilder
    private func accountAndPreferencesGroup(_ viewModel: SettingsViewModel) -> some View {
        // Account Section
        Section {
            if authenticationManager.isAuthenticated {
                // Signed In State
                HStack {
                    Image(systemName: "person.circle.fill")
                        .font(.title)
                        .foregroundColor(designSystem.colors.primaryBlack)

                    VStack(alignment: .leading, spacing: 4) {
                        Text(authenticationManager.userFullName ?? "User")
                            .font(designSystem.typography.body)
                            .foregroundColor(designSystem.colors.textPrimary)

                        if let userID = authenticationManager.userID {
                            Text("ID: \(userID)")
                                .font(designSystem.typography.caption)
                                .foregroundColor(designSystem.colors.textSecondary)
                        }
                    }
                }
                .padding(.vertical, 4)

                Button {
                    showingAuthenticationView = true
                } label: {
                    HStack {
                        Image(systemName: "person.badge.key")
                        Text("Manage Account")
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.caption)
                            .foregroundColor(designSystem.colors.textSecondary)
                    }
                }

                Button(role: .destructive) {
                    showingSignOutAlert = true
                } label: {
                    HStack {
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                        Text("Sign Out")
                    }
                }
            } else {
                // Not Signed In State
                Button {
                    showingAuthenticationView = true
                } label: {
                    HStack {
                        Image(systemName: "person.badge.key")
                            .foregroundColor(designSystem.colors.primaryBlack)
                        Text("Sign In with Apple")
                            .foregroundColor(designSystem.colors.textPrimary)
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.caption)
                            .foregroundColor(designSystem.colors.textSecondary)
                    }
                }
            }
        } header: {
            Text("Account")
        } footer: {
            if !authenticationManager.isAuthenticated {
                Text("Sign in to access all features and sync your data across devices")
            }
        }

        // Subscription Section
        Section {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Current Plan")
                        .font(designSystem.typography.caption)
                        .foregroundColor(designSystem.colors.textSecondary)

                    HStack {
                        Text(subscriptionManager.currentTier.displayName)
                            .font(designSystem.typography.body)
                            .foregroundColor(designSystem.colors.textPrimary)

                        if subscriptionManager.isPaidSubscriber {
                            Image(systemName: "checkmark.seal.fill")
                                .foregroundColor(.green)
                        }
                    }
                }

                Spacer()

                if subscriptionManager.currentTier == .basic {
                    Button("Upgrade") {
                        showingSubscriptionView = true
                    }
                    .font(designSystem.typography.caption)
                    .foregroundColor(designSystem.colors.primaryBlack)
                }
            }
            .padding(.vertical, 4)

            Button {
                showingSubscriptionView = true
            } label: {
                HStack {
                    Image(systemName: "star.circle")
                    Text("Manage Subscription")
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.caption)
                        .foregroundColor(designSystem.colors.textSecondary)
                }
            }
        } header: {
            Text("Subscription")
        } footer: {
            if subscriptionManager.currentTier == .basic {
                Text("Upgrade to Premium for unlimited data storage, advanced analytics, and more")
            }
        }

        // App Mode Section
        Section {
            HStack {
                Image(systemName: "person.fill")
                    .foregroundColor(designSystem.colors.primaryBlack)

                VStack(alignment: .leading, spacing: 4) {
                    Text("Current Mode")
                        .font(designSystem.typography.caption)
                        .foregroundColor(designSystem.colors.textSecondary)

                    Text(appStateManager.selectedMode?.rawValue ?? "Full Access")
                        .font(designSystem.typography.body)
                        .foregroundColor(designSystem.colors.textPrimary)
                }
            }
            .padding(.vertical, 4)

            Button {
                showingChangeModeAlert = true
            } label: {
                HStack {
                    Image(systemName: "arrow.triangle.2.circlepath")
                    Text("Change Mode")
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.caption)
                        .foregroundColor(designSystem.colors.textSecondary)
                }
            }
        } header: {
            Text("App Mode")
        } footer: {
            Text("Patient app with full subscription access")
        }
    }

    @ViewBuilder
    private func deviceAndNotificationsGroup(_ viewModel: SettingsViewModel) -> some View {
        // Device Settings Section
        Section {
            // PPG Channel Order
            NavigationLink {
                PPGChannelOrderView(selectedOrder: $viewModel.ppgChannelOrder)
            } label: {
                HStack {
                    Text("PPG Channel Order")
                    Spacer()
                    Text(viewModel.ppgChannelOrder.displayName)
                        .foregroundColor(designSystem.colors.textSecondary)
                }
            }

            // Auto-connect
            Toggle("Auto-connect", isOn: $viewModel.autoConnectEnabled)

            // Debug Info
            Toggle("Show Debug Info", isOn: $viewModel.showDebugInfo)
                .tint(designSystem.colors.primaryBlack)
        } header: {
            Text("Device Settings")
        }

        // Notification Settings Section
        Section {
            Toggle("Notifications", isOn: $viewModel.notificationsEnabled)
                .tint(designSystem.colors.primaryBlack)

            if viewModel.notificationsEnabled {
                Toggle("Connection Alerts", isOn: $viewModel.connectionAlerts)
                    .tint(designSystem.colors.primaryBlack)

                Toggle("Battery Alerts", isOn: $viewModel.batteryAlerts)
                    .tint(designSystem.colors.primaryBlack)

                if viewModel.batteryAlerts {
                    Stepper("Low Battery: \(viewModel.lowBatteryThreshold)%",
                           value: $viewModel.lowBatteryThreshold,
                           in: 5...50,
                           step: 5)
                }
            }
        } header: {
            Text("Notifications")
        }

        // Display Settings Section
        Section {
            Toggle("Use Metric Units", isOn: $viewModel.useMetricUnits)
                .tint(designSystem.colors.primaryBlack)

            Toggle("24-Hour Time", isOn: $viewModel.show24HourTime)
                .tint(designSystem.colors.primaryBlack)

            Picker("Chart Refresh", selection: $viewModel.chartRefreshRate) {
                ForEach(ChartRefreshRate.allCases, id: \.self) { rate in
                    Text(rate.rawValue).tag(rate)
                }
            }
        } header: {
            Text("Display")
        }
    }

    @ViewBuilder
    private func healthIntegrationGroup(_ viewModel: SettingsViewModel) -> some View {
        // Health Integration Section
        if healthKitManager.isAvailable {
            Section {
                // Authorization Status
                HStack {
                    Image(systemName: "heart.circle.fill")
                        .foregroundColor(.red)

                    VStack(alignment: .leading, spacing: 4) {
                        Text("Apple Health")
                            .font(designSystem.typography.body)
                            .foregroundColor(designSystem.colors.textPrimary)

                        if healthKitManager.isAuthorized {
                            HStack(spacing: 4) {
                                Image(systemName: "checkmark.seal.fill")
                                    .font(.caption)
                                    .foregroundColor(.green)
                                Text("Connected")
                                    .font(designSystem.typography.caption)
                                    .foregroundColor(designSystem.colors.textSecondary)
                            }
                        } else {
                            Text("Not Connected")
                                .font(designSystem.typography.caption)
                                .foregroundColor(designSystem.colors.textSecondary)
                        }
                    }

                    Spacer()

                    if !healthKitManager.isAuthorized {
                        Button("Connect") {
                            Task {
                                try? await healthKitManager.requestAuthorization()
                            }
                        }
                        .font(designSystem.typography.caption)
                        .foregroundColor(designSystem.colors.primaryBlack)
                    }
                }
                .padding(.vertical, 4)
            } header: {
                Text("Health Integration")
            } footer: {
                Text("Sync your health data with Apple Health for a complete view of your wellness")
            }
        }
    }

    @ViewBuilder
    private func dataAndPrivacyGroup(_ viewModel: SettingsViewModel) -> some View {
        // Data Management Section
        Section {
            Stepper("Retention: \(viewModel.dataRetentionDays) days",
                   value: $viewModel.dataRetentionDays,
                   in: 1...365)

            Button(role: .destructive) {
                viewModel.showClearDataConfirmation = true
            } label: {
                HStack {
                    Image(systemName: "trash")
                    Text("Clear All Data")
                }
            }
        } header: {
            Text("Data Management")
        } footer: {
            Text("Data older than \(viewModel.dataRetentionDays) days will be automatically deleted.")
        }

        // Privacy Section
        Section {
            Toggle("Share Analytics", isOn: $viewModel.shareAnalytics)
                .tint(designSystem.colors.primaryBlack)

            Toggle("Local Storage Only", isOn: $viewModel.localStorageOnly)
                .tint(designSystem.colors.primaryBlack)
        } header: {
            Text("Privacy")
        } footer: {
            Text("When enabled, all data stays on this device and is never sent to cloud services.")
        }

        // Export & Share Section
        Section {
            Button {
                showingExportSheet = true
            } label: {
                HStack {
                    Image(systemName: "square.and.arrow.up")
                        .foregroundColor(designSystem.colors.primaryBlack)
                    Text("Export Data")
                        .foregroundColor(designSystem.colors.textPrimary)
                }
            }
        } header: {
            Text("Data Export")
        }

        // About Section
        Section {
            InfoRowView(icon: "info.circle", title: "Version", value: viewModel.appVersion)
            InfoRowView(icon: "number", title: "Build", value: viewModel.buildNumber)

            Button {
                viewModel.showResetConfirmation = true
            } label: {
                HStack {
                    Image(systemName: "arrow.counterclockwise")
                    Text("Reset to Defaults")
                }
            }
        } header: {
            Text("About")
        } footer: {
            Text(viewModel.versionText)
                .frame(maxWidth: .infinity, alignment: .center)
                .foregroundColor(designSystem.colors.textTertiary)
                .padding(.top, designSystem.spacing.md)
        }
    }
}

// MARK: - PPG Channel Order View

struct PPGChannelOrderView: View {
    @EnvironmentObject var designSystem: DesignSystem
    @Environment(\.dismiss) private var dismiss
    @Binding var selectedOrder: PPGChannelOrder

    var body: some View {
        List {
            ForEach(PPGChannelOrder.allCases, id: \.self) { order in
                Button {
                    selectedOrder = order
                    dismiss()
                } label: {
                    HStack {
                        Text(order.displayName)
                            .font(designSystem.typography.body)
                            .foregroundColor(designSystem.colors.textPrimary)

                        Spacer()

                        if order == selectedOrder {
                            Image(systemName: "checkmark")
                                .foregroundColor(designSystem.colors.primaryBlack)
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .navigationTitle("PPG Channel Order")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - PPGChannelOrder Extension

extension PPGChannelOrder {
    var displayName: String {
        return self.rawValue
    }
}


// MARK: - Preview

#Preview("Settings View") {
    let designSystem = DesignSystem()
    
    // Create mock/preview dependencies
    let authManager = AuthenticationManager()
    let healthKitManager = HealthKitManager()
    let bleManager = OralableBLE()
    let recordingSessionManager = RecordingSessionManager()
    let historicalDataManager = HistoricalDataManager(sensorDataProcessor: SensorDataProcessor.shared)
    let sensorDataStore = SensorDataStore()
    let subscriptionManager = SubscriptionManager()
    let deviceManager = DeviceManager()
    let appStateManager = AppStateManager()
    let sharedDataManager = SharedDataManager(
        authenticationManager: authManager,
        healthKitManager: healthKitManager,
        sensorDataProcessor: SensorDataProcessor.shared
    )
    
    let dependencies = AppDependencies(
        authenticationManager: authManager,
        healthKitManager: healthKitManager,
        recordingSessionManager: recordingSessionManager,
        historicalDataManager: historicalDataManager,
        bleManager: bleManager,
        sensorDataStore: sensorDataStore,
        subscriptionManager: subscriptionManager,
        deviceManager: deviceManager,
        sensorDataProcessor: SensorDataProcessor.shared,
        appStateManager: appStateManager,
        sharedDataManager: sharedDataManager,
        designSystem: designSystem
    )
    
    SettingsView(viewModel: dependencies.makeSettingsViewModel())
        .withDependencies(dependencies)
        .environmentObject(designSystem)
}
