import Foundation
import Combine

@MainActor
class AddPatientViewModel: ObservableObject {
    // MARK: - Published Properties

    @Published var shareCode: String = ""
    @Published var isAdding: Bool = false
    @Published var errorMessage: String?
    @Published var successMessage: String?
    @Published var shouldDismiss: Bool = false

    // MARK: - Dependencies

    private let dataManager: DentistDataManager
    private let subscriptionManager: DentistSubscriptionManager
    private var cancellables = Set<AnyCancellable>()

    // MARK: - Computed Properties

    var isShareCodeValid: Bool {
        return shareCode.count == 6 && Int(shareCode) != nil
    }

    var canAddPatient: Bool {
        return !isAdding && isShareCodeValid
    }

    // MARK: - Initialization

    init(dataManager: DentistDataManager, subscriptionManager: DentistSubscriptionManager) {
        self.dataManager = dataManager
        self.subscriptionManager = subscriptionManager

        // Subscribe to data manager updates
        dataManager.$isLoading
            .receive(on: DispatchQueue.main)
            .assign(to: &$isAdding)

        dataManager.$errorMessage
            .receive(on: DispatchQueue.main)
            .sink { [weak self] error in
                self?.errorMessage = error
            }
            .store(in: &cancellables)

        dataManager.$successMessage
            .receive(on: DispatchQueue.main)
            .sink { [weak self] success in
                if success != nil {
                    self?.successMessage = success
                    // Auto-dismiss after success
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        self?.shouldDismiss = true
                    }
                }
            }
            .store(in: &cancellables)
    }

    // MARK: - Actions

    func addPatient() {
        guard canAddPatient else { return }

        // Check subscription limits
        let currentPatientCount = dataManager.patients.count
        if !subscriptionManager.canAddMorePatients(currentCount: currentPatientCount) {
            errorMessage = "You've reached your patient limit. Please upgrade to add more patients."
            return
        }

        Task {
            do {
                try await dataManager.addPatientWithShareCode(shareCode)
                shareCode = ""
            } catch {
                // Error is handled by subscription to dataManager.$errorMessage
            }
        }
    }

    func clearMessages() {
        errorMessage = nil
        successMessage = nil
    }

    func formatShareCode(_ input: String) -> String {
        // Only allow digits, max 6 characters
        let filtered = input.filter { $0.isNumber }
        return String(filtered.prefix(6))
    }
}
